
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ICE-I2C-FT6206' 
 * Target:  'ICE-I2C-FT6206' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "TM4C123.h"


#endif /* RTE_COMPONENTS_H */
